package com.example.beautiful_bangladesh;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.webkit.WebView;

public class MainActivity extends AppCompatActivity {

    private WebView webView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        webView=(WebView) findViewById(R.id.webViewId);
        webView.loadUrl("https://www.google.com/search?q=bangladesh&oq=BAN&aqs=chrome.0.69i59j46i39j69i57j0i433j0i131i433j69i60j69i61l2.2940j0j9&sourceid=chrome&ie=UTF-8");
    }
}